//LianZ
//Alina Zeng
package com.example.project4task2.model;

import java.io.Serializable;

public class Player implements Serializable {
    private int id;
    private String firstName;
    private String lastName;
    private String position;
    private String team;

    // Constructor, getters, setters, etc.

    public Player(int id, String firstName, String lastName, String position, String team) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.team = team;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTeam() {
        return team;
    }

    public int getId() {
        return id;
    }

    // ... other methods ...
}
