//LianZ
//Alina Zeng
package com.example.project4task2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.project4task2.adapter.PlayerAdapter;
import com.example.project4task2.model.Player;

import java.util.ArrayList;

public class SearchResultsActivity extends AppCompatActivity {
    private RecyclerView recyclerViewPlayers;
    private PlayerAdapter playerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        recyclerViewPlayers = findViewById(R.id.recyclerViewPlayers);

        // Retrieve the list of players passed from MainActivity
        ArrayList<Player> players = (ArrayList<Player>) getIntent().getSerializableExtra("players");

        // Set up the RecyclerView
        recyclerViewPlayers.setLayoutManager(new LinearLayoutManager(this));
        playerAdapter = new PlayerAdapter(players, this, false);
        recyclerViewPlayers.setAdapter(playerAdapter);
    }
}
