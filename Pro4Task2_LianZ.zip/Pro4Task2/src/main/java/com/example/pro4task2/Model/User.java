//LianZ
//Alina Zeng
package com.example.pro4task2.Model;

import java.util.List;

/**
 * Represents a user in the application.
 */
public class User {
    private String username; // Stores the username of the user
    private List<String> favoritePlayerIds; // List to store IDs of the user's favorite players

    /**
     * Constructor to create a new user.
     * @param username User's name.
     * @param favoritePlayerIds List of favorite player IDs.
     */
    public User(String username, List<String> favoritePlayerIds) {
        this.username = username;
        this.favoritePlayerIds = favoritePlayerIds;
    }

    // Getters and setters

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public List<String> getFavoritePlayerIds() { return favoritePlayerIds; }
    public void setFavoritePlayerIds(List<String> favoritePlayerIds) { this.favoritePlayerIds = favoritePlayerIds; }
}
