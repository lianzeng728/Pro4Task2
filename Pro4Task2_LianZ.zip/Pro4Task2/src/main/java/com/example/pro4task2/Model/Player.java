//LianZ
//Alina Zeng
package com.example.pro4task2.Model;

/**
 * Represents an NBA player.
 */
public class Player {
    private int id; // Unique identifier for the player
    private String firstName; // Player's first name
    private String lastName; // Player's last name
    private String position; // Player's position in the team
    private String team; // Team to which the player belongs

    /**
     * Constructor to create a new player.
     * @param id Unique identifier for the player.
     * @param firstName Player's first name.
     * @param lastName Player's last name.
     * @param position Player's position.
     * @param team Player's team.
     */
    public Player(int id, String firstName, String lastName, String position, String team) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
        this.team = team;
    }

    // Getters and setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
}
