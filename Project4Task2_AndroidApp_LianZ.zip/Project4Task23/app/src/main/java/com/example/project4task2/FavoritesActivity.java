//LianZ
//Alina Zeng
package com.example.project4task2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.project4task2.adapter.PlayerAdapter;
import com.example.project4task2.model.Player;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class FavoritesActivity extends AppCompatActivity {
    private RecyclerView recyclerViewFavorites;
    private Button buttonBack;
    private PlayerAdapter playerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        // Initializing RecyclerView and Adapter for displaying favorite players.
        recyclerViewFavorites = findViewById(R.id.recyclerViewFavorites);
        buttonBack = findViewById(R.id.buttonBack);

        // Initialize RecyclerView and Adapter
        recyclerViewFavorites.setLayoutManager(new LinearLayoutManager(this));
        playerAdapter = new PlayerAdapter(new ArrayList<>(), this, true);
        recyclerViewFavorites.setAdapter(playerAdapter);

        // Fetch favorite players
        fetchFavoritePlayers();

        // Handling back button click to navigate to the main search activity.
        buttonBack.setOnClickListener(v -> {
            // Navigate back to MainActivity
            startActivity(new Intent(FavoritesActivity.this, MainActivity.class));
        });
    }

    /*
    * Method to fetch favorite players from the server.
    * */
    private void fetchFavoritePlayers() {
        new Thread(() -> {
            try {
                URL url = new URL("https://studious-barnacle-7vvr556jr67j26g-8080.app.github.dev/user");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                Scanner scanner = new Scanner(connection.getInputStream());
                StringBuilder response = new StringBuilder();
                while (scanner.hasNextLine()) {
                    response.append(scanner.nextLine());
                }
                scanner.close();

                // Parsing the response to get the favorite player IDs.
                JSONObject userObject = new JSONObject(response.toString());
                JSONArray favoritePlayerIds = userObject.getJSONArray("favoritePlayerIds");

                // Fetching each player's details by their ID and updating the UI.
                for (int i = 0; i < favoritePlayerIds.length(); i++) {
                    int playerId = favoritePlayerIds.getInt(i);
                    Player player = fetchPlayerById(playerId);
                    if (player != null) {
                        runOnUiThread(() -> playerAdapter.addPlayer(player));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    // Method to fetch a player's details by their ID.
    private Player fetchPlayerById(int playerId) {
        try {
            URL url = new URL("https://studious-barnacle-7vvr556jr67j26g-8080.app.github.dev/players?playerId=" + playerId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            Scanner scanner = new Scanner(connection.getInputStream());
            StringBuilder jsonResponseBuilder = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonResponseBuilder.append(scanner.nextLine());
            }
            scanner.close();

            // Parsing the JSON response to create a Player object.
            String jsonResponse = jsonResponseBuilder.toString();
            JSONArray jsonArray = new JSONArray(jsonResponse);

            // Assuming that the playerId is unique and only one player will be returned
            if (jsonArray.length() > 0) {
                JSONObject jsonPlayer = jsonArray.getJSONObject(0);
                return new Player(
                        jsonPlayer.getInt("id"),
                        jsonPlayer.getString("firstName"),
                        jsonPlayer.getString("lastName"),
                        jsonPlayer.optString("position", "N/A"),
                        jsonPlayer.getString("team")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}

