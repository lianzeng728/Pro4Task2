//LianZ
//Alina Zeng
package com.example.project4task2.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project4task2.FavoritesActivity;
import com.example.project4task2.R;
import com.example.project4task2.model.Player;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


// Adapter class for managing the display of NBA player information in a RecyclerView.
public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder> {
    private List<Player> playersList;
    private Context context;
    private boolean isFavoritesList;

    // Constructor to initialize the adapter with player data and context.
    public PlayerAdapter(List<Player> playersList, Context context, boolean isFavoritesList) {
        this.playersList = playersList != null ? playersList : new ArrayList<>();
        this.context = context;
        this.isFavoritesList = isFavoritesList;
    }

    // Add a player to the list and refresh the adapter.
    public void addPlayer(Player player) {
        playersList.add(player);
        notifyDataSetChanged();
    }

    // Inflating the layout for each item in the RecyclerView.
    @NonNull
    @Override
    public PlayerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.player_item, parent, false);
        return new PlayerViewHolder(view);
    }

    // Binding data to each item in the RecyclerView.
    @Override
    public void onBindViewHolder(@NonNull PlayerViewHolder holder, int position) {
        Player player = playersList.get(position);
        holder.textViewPlayerName.setText(player.getFirstName() + " " + player.getLastName());

        if (!isFavoritesList) {
            holder.btnAddToFavorites.setVisibility(View.VISIBLE);
            holder.btnAddToFavorites.setOnClickListener(v -> addToFavorites(player.getId()));
        } else {
            holder.btnAddToFavorites.setVisibility(View.GONE);
        }
    }

    // Returns the total number of items in the list.
    @Override
    public int getItemCount() {
        return playersList.size();
    }

    // Method to handle adding a player to favorites.
    private void addToFavorites(int playerId) {
        new Thread(() -> {
            try {
                // Forming the URL for the POST request.
                String requestUrl = "https://studious-barnacle-7vvr556jr67j26g-8080.app.github.dev/user";
                Log.d("PlayerAdapter", "Sending request to: " + requestUrl);

                URL url = new URL(requestUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Sending player ID as POST data.
                String postData = "playerId=" + playerId;
                connection.getOutputStream().write(postData.getBytes(StandardCharsets.UTF_8));

                int responseCode = connection.getResponseCode();
                Log.d("PlayerAdapter", "Response code for adding to favorites: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    ((Activity) context).runOnUiThread(() -> {
                        Log.d("PlayerAdapter", "Added to favorites successfully.");
                        Toast.makeText(context, "Added to favorites!", Toast.LENGTH_SHORT).show();
                        context.startActivity(new Intent(context, FavoritesActivity.class));
                    });
                } else {
                    ((Activity) context).runOnUiThread(() -> {
                        Log.e("PlayerAdapter", "Failed to add to favorites. Response code: " + responseCode);
                        Toast.makeText(context, "Failed to add to favorites", Toast.LENGTH_SHORT).show();
                    });
                }
            } catch (Exception e) {
                Log.e("PlayerAdapter", "Exception in addToFavorites", e);
            }
        }).start();
    }

    // ViewHolder class to hold and bind views for each player item.
    public static class PlayerViewHolder extends RecyclerView.ViewHolder {
        TextView textViewPlayerName;
        TextView textViewPlayerTeam;
        Button btnAddToFavorites;

        public PlayerViewHolder(View itemView) {
            super(itemView);
            textViewPlayerName = itemView.findViewById(R.id.textViewPlayerName);
            textViewPlayerTeam =  itemView.findViewById(R.id.textViewPlayerTeam);
            btnAddToFavorites = itemView.findViewById(R.id.btnAddToFavorites);
        }
    }
}
