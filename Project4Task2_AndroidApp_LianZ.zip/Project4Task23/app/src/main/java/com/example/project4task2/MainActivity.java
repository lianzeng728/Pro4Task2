//LianZ
//Alina Zeng
package com.example.project4task2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.project4task2.model.Player;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private EditText editTextSearch;
    private Button buttonSearch;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing UI elements for searching players.
        editTextSearch = findViewById(R.id.editTextSearch);
        buttonSearch = findViewById(R.id.buttonSearch);

        // Handling search button click to initiate player search.
        buttonSearch.setOnClickListener(v -> {
            String searchTerm = editTextSearch.getText().toString();
            if (!searchTerm.isEmpty()) {
                fetchPlayers(searchTerm);
            }
        });
    }

    // Method to execute the player search in a separate thread.
    private void fetchPlayers(String searchTerm) {
        executorService.execute(() -> {
            List<Player> players = doInBackground(searchTerm);
            handler.post(() -> onPostExecute(players));
        });
    }

    // Background task for fetching player data from the server.
    private List<Player> doInBackground(String searchTerm) {
        try {
            URL url = new URL("https://studious-barnacle-7vvr556jr67j26g-8080.app.github.dev/players?searchTerm=" + searchTerm);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            int responseCode = urlConnection.getResponseCode();
            Log.d("FetchPlayersTask", "HTTP Response Code: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                bufferedReader.close();
                Log.d("FetchPlayersTask", "Response: " + stringBuilder.toString());
                return parsePlayersJson(stringBuilder.toString());
            } else {
                Log.e("FetchPlayersTask", "Error response from server: " + responseCode);
                return null;
            }
        } catch (Exception e) {
            Log.e("FetchPlayersTask", "Error: " + e.getMessage(), e);
            return null;
        }
    }

    // Method to execute post reqwurest
    private void onPostExecute(List<Player> players) {
        if (players != null) {
            Intent intent = new Intent(MainActivity.this, SearchResultsActivity.class);
            intent.putExtra("players", (ArrayList<Player>) players);
            startActivity(intent);
        } else {
            Toast.makeText(MainActivity.this, "Failed to fetch players. Please try again.", Toast.LENGTH_LONG).show();
        }
    }


    // Method to parse player JSON Object
    private List<Player> parsePlayersJson(String json) {
        try {
            List<Player> players = new ArrayList<>();
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonPlayer = jsonArray.getJSONObject(i);
                Player player = new Player(
                        jsonPlayer.getInt("id"),
                        jsonPlayer.getString("firstName"),
                        jsonPlayer.getString("lastName"),
                        jsonPlayer.getString("position"),
                        jsonPlayer.getString("team")
                );
                players.add(player);
            }
            return players;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}
